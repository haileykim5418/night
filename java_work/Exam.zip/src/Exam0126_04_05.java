import java.util.Scanner;

public class Exam0126_04_05 {

	public static void main(String[] args) {
	char eng[] = {'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','x','w'};
	char kor[] = {'ㄱ','ㄴ','ㄷ','ㄹ','ㅁ','ㅂ','ㅅ','ㅇ','ㅈ','ㅊ','ㅋ','ㅌ','ㅍ','ㅎ','ㅏ','ㅑ','ㅓ','ㅕ','ㅗ','ㅛ','ㅜ','ㅠ','ㅡ','ㅣ'};
	Scanner s = new Scanner(System.in);
	System.out.println("알파벳 입력:");
	
//	for(int i=0;i<=eng.length;i++) {
//		eng[i]=i;
//		if()
//		
//		
		
	}
	
	

	}


