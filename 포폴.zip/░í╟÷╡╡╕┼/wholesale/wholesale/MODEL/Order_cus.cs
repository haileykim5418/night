﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wholesale.MODEL
{
    class Order_cus
    {
        public CustomersData cus { get; set; }
        
        public Order_cus(CustomersData cus)
        {
            this.cus = cus;
        }

        

    }
}
