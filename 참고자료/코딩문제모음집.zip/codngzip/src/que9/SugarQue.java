package que9;

import java.util.Scanner;

public class SugarQue {
	public static void main(String[] args) {
		System.out.println("설탕공장에서 요청한 설탕 kg수?");
		Scanner scan = new Scanner(System.in);
		int inputSugar = scan.nextInt();
		scan.nextLine(); //공백 흡수용 코드, 여기선 별 필요 없다.
		int countSugarPackage = 0;
		while(true)
		{
            if(inputSugar % 5 == 0)
            {
                countSugarPackage += inputSugar / 5;
                System.out.println(countSugarPackage);
                break;
            }
            inputSugar -= 3;
            countSugarPackage++;

            if(inputSugar < 0)
            {
            	System.out.println("-1");
                break;
            }
		}
	}
}
