package Question15_16_17;

public class Doctor
{
	//id 이름 부서명 성별(15번문제 클래스 작성하기)
	public String id; //id
	public String name; //이름
	public String department; //부서명
	private int gender; //성별
	
	public static final int Man = 0;
	public static final int Woman = 1;
	
	public void setGender(String inputGender )
	{
		if(checkValidateGender(inputGender))
		{
			System.out.println("잘못된 값을 입력하셨습니다. 디폴트 값인 Man=0 으로 세팅하겠습니다.");
			gender = Man;
		}
	}
	
	public int getGender()
	{
		return gender;
	}
	
	public boolean checkValidateGender( String inputGender )
	{
		try
		{
			gender = Integer.parseInt(inputGender);
			if(gender == Man || gender == Woman)
			{
				return true;
			}
			return false;
		}catch (Exception e) {
			e.printStackTrace();
			System.out.println("숫자 이외의 값을 입력하였습니다." + inputGender);
			return false;
		}
	}
	
	//toString을 오버라이딩하면 좀 더 쉽게 데이터를 출력 가능 (1번 문제 참고)
}
