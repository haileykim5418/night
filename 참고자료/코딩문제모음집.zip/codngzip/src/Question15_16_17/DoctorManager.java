package Question15_16_17;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

import java.util.List;

public class DoctorManager
{
	//가독성 향상을 위하여 상수 사용
	static final int Man = 0;
	static final int Woman = 1;
	
	public static boolean isThereDuplicateId(Doctor[] doctorList, int length, String checkId)
	{
		for(int j = 0; j<length; j++)
		{
			//System.out.println(doctorList[0].id);
			if(checkId.equals(doctorList[j].id))
			{
				System.out.println("이미 존재하는 id입니다." + checkId + "   " + doctorList[j].id);
				return true;
			}
		}
		return false;
	}

	public static void main(String[] args)
	{
		Doctor tempDoctor = new Doctor();
		tempDoctor.id = "tempId";
		tempDoctor.name = "tempLee";
		tempDoctor.department = "tempDepartment";
		//tempDoctor.gender = Man;
		tempDoctor.setGender("0");
		System.out.println("성별은 " + tempDoctor.getGender() + "입니다.");
		
		//의사 10명을 추가하는 코드. 
		//id 중복을 불허한다.

		//배열 - 단순 for문 버전(선형탐색 = linear Search)
		//순차정렬되어있다면 binarySearch로 찾을 수도 있긴하다.
		Doctor[] doctorList = new Doctor[10];
		Scanner s = new Scanner(System.in);
		for (int i = 0; i < doctorList.length; i++)
		{
			//class는 참조변수이다. 따라서 이 변수가 바뀌면, 이 변수를 사용한 부분들이 모두 바뀜
			//그래서 new 키워드를 통하여 공간을 새롭게 할당하는 것이다.
			tempDoctor = new Doctor(); 
			System.out.println("id? ");
			tempDoctor.id = s.nextLine();
			boolean isDuplicateId = isThereDuplicateId(doctorList, i, tempDoctor.id);
			if(isDuplicateId)
			{
				i--;
				continue;
			}
			System.out.println("name? ");
			tempDoctor.name = s.nextLine();
			System.out.println("department? ");
			tempDoctor.department = s.nextLine();
			System.out.println("성별을 입력하시오. 남성은 0, 여성은 1을 입력하시오.");
			while(false == tempDoctor.checkValidateGender(s.nextLine()))
			{
				System.out.println("유효하지 않은 값이므로 성별을 다시 입력하여 주시길 바랍니다.");
			}
			doctorList[i] = tempDoctor;
		}
		
		System.out.println("10명 입력 끝(doctorlist)");	
		
		//배열 - Library 사용 버전
		Doctor[] doctorList2 = new Doctor[10];
		String[] idListForCheck = new String[10];
		for (int i = 0; i < doctorList2.length; i++)
		{
			tempDoctor = new Doctor(); 
			System.out.println("id? ");
			tempDoctor.id = s.nextLine();
			boolean isDuplicateId = Arrays.asList(idListForCheck).contains(tempDoctor.id);
			if(isDuplicateId)
			{
				i--;
				continue;
			}
			System.out.println("name? ");
			tempDoctor.name = s.nextLine();
			System.out.println("department? ");
			tempDoctor.department = s.nextLine();
			System.out.println("성별을 입력하시오. 남성은 0, 여성은 1을 입력하시오.");
			while(false == tempDoctor.checkValidateGender(s.nextLine()))
			{
				System.out.println("유효하지 않은 값이므로 성별을 다시 입력하여 주시길 바랍니다.");
			}
			doctorList2[i] = tempDoctor;
			idListForCheck[i] = tempDoctor.id;
		}
		System.out.println("10명 입력 끝(doctorlist2)");
		
		//List 사용 버전
		List<Doctor> doctorList3 = new ArrayList<Doctor>();
		List<String> doctorIdList = new ArrayList<String>();
		//ArrayList<Doctor> doctorList3 = new ArrayList<Doctor>();
		
		for (int i = 0; i < 10; i++)
		{
			tempDoctor = new Doctor(); 
			System.out.println("id? ");
			tempDoctor.id = s.nextLine();
			boolean isDuplicateId = doctorIdList.contains(tempDoctor.id);
			if(isDuplicateId)
			{
				i--;
				continue;
			}
			System.out.println("name? ");
			tempDoctor.name = s.nextLine();
			System.out.println("department? ");
			tempDoctor.department = s.nextLine();
			System.out.println("성별을 입력하시오. 남성은 0, 여성은 1을 입력하시오.");
			while(false == tempDoctor.checkValidateGender(s.nextLine()))
			{
				System.out.println("유효하지 않은 값이므로 성별을 다시 입력하여 주시길 바랍니다.");
			}
			doctorList3.add(tempDoctor);
			doctorIdList.add(tempDoctor.id);
		}
		System.out.println("10명 입력 끝(doctorlist3)");
		
		for (int i = 0; i < 10; i++)
		{
			System.out.println(doctorList[i].name + " "+ doctorList[i].id);
			System.out.println();
			System.out.println(doctorList2[i].name + " "+ doctorList2[i].id);
			System.out.println();
			System.out.println(doctorList3.get(i).name + " "+ doctorList3.get(i).id);
		}
	}

}
