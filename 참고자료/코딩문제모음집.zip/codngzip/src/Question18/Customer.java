package Question18;

public class Customer
{
	public String name;
	public int number;
	public int birthYear;
	public String identifier;
	public String id;
	public String password;

	public boolean isThisDigit(char c)
	{
		if (c >= '0' && c <= '9')
		{
			return true;
		}
		return false;
	}
	
	public boolean isThisAlphabet(char c)
	{
		if (c >= 'a' && c <= 'z')
		{
			return true;
		}
		else if(c >= 'A' && c <= 'Z')
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public boolean isSpecialCharacters(char c)
	{
		if (c >= '!' && c <= '/')
		{
			return true;
		}
		else if(c >= ';' && c <= '@')
		{
			return true;
		}
		else if(c >= '[' && c <= '`')
		{
			return true;
		}
		else if(c >= '{' && c <='~')
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	// 무조건 4글자여야 한다.
	public boolean checkLevel1()
	{
		if(password.length() != 4)
			return false;
		
		return true;
	}

	// 무조건 8자 이상이어야 한다.
	public boolean checkLevel2()
	{
		if(password.length() < 8)
			return false;
		
		return true;
	}

	// 무조건 숫자로만 되어있어야 한다.
	public boolean checkLevel3()
	{
		for (int i = 0; i < password.length(); i++)
		{
			if (false == isThisDigit(password.charAt(i)))
			{
				return false;
			}
		}
		return true;
	}
	
	// 영어와 숫자의 조합으로 되어야 한다.
	public boolean checkLevel4()
	{
		int countDigit = 0;
		int countAlpha = 0;
		for (int i = 0; i < password.length(); i++)
		{
			if (isThisDigit(password.charAt(i)))
			{
				countDigit++;
			}
			else if(isThisAlphabet(password.charAt(i)))
			{
				countAlpha++;
			}
		}
		if(countDigit == 0 || countAlpha == 0)
		{
			return false;
		}
		return true;
	}

	// 영어와 숫자 그리고 특수 문자의 조합으로 되어야 한다.
	public boolean checkLevel5()
	{
		int countDigit = 0;
		int countAlpha = 0;
		int countSpecialCharacter = 0;
		System.out.println("password : " + password);
		for (int i = 0; i < password.length(); i++)
		{
			if (isThisDigit(password.charAt(i)))
			{
				countDigit++;
			}
			else if(isThisAlphabet(password.charAt(i)))
			{
				countAlpha++;
			}
			else if(isSpecialCharacters(password.charAt(i)))
			{
				countSpecialCharacter++;
			}
		}
		if(countDigit == 0 || countAlpha == 0 || countSpecialCharacter == 0)
		{
			return false;
		}
		return true;
	}

	// 영어와 숫자 그리고 특수문자까지 모두 포함되어 있어야 한다.
	public boolean checkValidate(int checkLevel)
	{
		switch (checkLevel)
		{
			case 1:
				return checkLevel1();
			case 2:
				return checkLevel2();
			case 3:
				return checkLevel3();
			case 4:
				return checkLevel4();
			default:
				return checkLevel5();
		}
	}
}
