package Question18;

import java.util.ArrayList;
import java.util.Scanner;

public class CustomerManager {

	public static void main(String[] args) {

		ArrayList<Customer> customers = new ArrayList<Customer>();
		ArrayList<String> customersIdList = new ArrayList<String>();

		Scanner s = new Scanner(System.in);
		for (int i = 0; i < 5; i++) {
			Customer tmp = new Customer();
			System.out.print("id? ");
			tmp.id = s.nextLine();

			if (customersIdList.contains(tmp.id)) {
				System.out.println("이미 존재하는 ID입니다.");
				i--;
				continue;
			}
			System.out.print("name? ");
			tmp.name = s.nextLine();
			System.out.print("identifier? ");
			tmp.identifier = s.nextLine();
			System.out.print("password? ");
			tmp.password = s.nextLine();
			while (!tmp.checkValidate(5)) // 단계설정가능
			{
				System.out.println("비밀번호가 유효하지 않습니다.");
				System.out.print("password? ");
				tmp.password = s.nextLine();
			}
			try {
				System.out.print("number? ");
				tmp.number = Integer.parseInt(s.nextLine());
				System.out.print("birthYear? ");
				tmp.birthYear = Integer.parseInt(s.nextLine());
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("유효하지 않은 숫자입니다.");
			}
			customers.add(tmp);
			customersIdList.add(tmp.id);
		}
	}
}
