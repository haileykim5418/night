package Question24;

import java.util.Scanner;

public class AnyPattern {
	public static void main(String[] args) {
		String start = "1";
		Scanner s = new Scanner(System.in);
		s = new Scanner(System.in);
		int nth = s.nextInt();
		s.close();
		for (int i = 0; i < nth; i++) {
			System.out.println((i + 1) + "번째 : " + start);
			// 누적값 혹은 뭔가 끊어주는 값
			String end = "";
			// 몇 개 인지 구해야 하는 숫자
			char number = start.charAt(0);
			// 가리키는 숫자의 개수
			int count = 0;
			for (int j = 0; j < start.length(); j++) {
				// 가리키는 숫자랑 다른 숫자가 나오는 경우
				if (number != start.charAt(j)) {
					end = end + number + count; // 11
					number = start.charAt(j); // number = 2;
					count = 1;
				} else // number == start.charAt(j)
				{
					count++;
				}

			}
			end = end + number + count; // 11 12 1121
			start = end; // 11 12

		}
	}
}
