package Question22;

import java.util.Scanner;

public class pyramid {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println("22번 문제");
		System.out.println("몇 층으로 쌓을래?");
		Scanner s = new Scanner(System.in);
		int floor = 0;

		try // 예외처리
		{
			floor = s.nextInt();
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("실패!!!");
			e.printStackTrace();
		} 
;

		for (int i = 0; i < floor; i++) {
			// 빈칸
			for (int j = floor; j >= i; j--) {
				System.out.print(" ");
			}
			for (int k = 0; k < 2 * i + 1; k++) {
				System.out.print("*");
			}
			System.out.println();
		}

	}

}
