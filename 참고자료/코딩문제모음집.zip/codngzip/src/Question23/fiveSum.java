package Question23;

import java.util.Scanner;

public class fiveSum {
	
	public static void main(String[] args) {

		int max;
		int min;
		max = Integer.MIN_VALUE;
		min = Integer.MAX_VALUE;

		Scanner s = new Scanner(System.in);
		for (int i = 0; i < 5; i++) {
			s = new Scanner(System.in);
			int compareValue = s.nextInt();
			if (compareValue > max)
				max = compareValue;
			if (compareValue < min)
				min = compareValue;
		}
		System.out.println(String.format("max : %d, min : %d", max, min));
	}


}
