package Question19;

import java.util.Date;
public class Student {

	public String name;
	public int age;
	public String studentNumber; //pk
	public String majorCode; //fk
	public Date regDate;
}
