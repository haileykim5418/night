package Question19;

import java.util.Date;
public class Major {

	public String name;
	public String code; //pk
	public Date regDate;
}
