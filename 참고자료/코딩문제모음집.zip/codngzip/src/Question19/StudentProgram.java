package Question19;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

public class StudentProgram {


	public static void main(String[] args) {
		ArrayList<Student> studentList = new ArrayList<Student>();
		ArrayList<String> studentNumberList = new ArrayList<String>();
		ArrayList<Major> majorList = new ArrayList<Major>();
		ArrayList<String> majorCodeList = new ArrayList<String>();
		Scanner s = new Scanner(System.in);
		
		//기본키 : UNIQUE + NOT NULL
		//외래키 : 참조키라고도 하며, 특정 테이블을 참조함.

		//학과코드가 외래키이므로 majorlist에 데이터를 먼저 넣는다.
		//이 데이터를 이용하여 추후 학생 데이터를 만들 수 있다.
		for(int i = 0; i < 3; i++)
		{
			Major major = new Major();
			//일반 자료형과 다르게 참조형 자료형은 함수 안에서 값이 바뀌어도, 그 것이 호출 이후에도 적용 되는 이유는?
			CreateMajor(major, s);		
			
			//대용량일수록 탐색이 느려진다. 그래서 HRD 등에서는 최근 1년 이내의 자료만 조회되게 함
			if(majorCodeList.contains(major.code)) 
			{
				System.out.println("이미 존재하는 학과코드입니다. 전공 정보를 다시 생성하여 주세요.");
				i--;
				continue;
			}
			
			majorCodeList.add(major.code);
			majorList.add(major);
		}
		
		//학생 데이터 추가
		for(int i = 0; i < 5; i++)
		{
			Student student = new Student();
			CreateStudent(student, s);
			
			//외래키 체크
			if(majorCodeList.contains(student.majorCode) == false)
			{
				System.out.println("해당 학과는 존재하지 않는 학과코드입니다. 학생 정보를 다시 생성하여 주세요.");
				i--;
				continue;
			}
			
			//기본키 체크
			if(studentNumberList.contains(student.studentNumber))
			{
				System.out.println("이미 존재하는 학번입니다. 전공 정보를 다시 생성하여 주세요.");
				i--;
				continue;
			}	
			
			studentNumberList.add(student.studentNumber);
			studentList.add(student);
		}

		SimpleDateFormat format = new SimpleDateFormat("yyyy년MM월dd일");
		for(int i = 0; i<majorList.size(); i++)
		{
			String regTime = format.format(majorList.get(i).regDate);
			System.out.println("학과명 : " + majorList.get(i).name + 
					"\n학과코드 : " + majorList.get(i).code + 
					"\n등록일 : " + regTime);
		}
		for(int i = 0; i<studentList.size(); i++)
		{
			String regTime = format.format(studentList.get(i).regDate);
			System.out.println("이름 : " + studentList.get(i).name + 
			"\n나이 : " + studentList.get(i).age +  
			"\n학번 : " + studentList.get(i).studentNumber + 
			"\n학과코드 : " + studentList.get(i).majorCode
			+"\n등록일 : " + regTime);
		}
		
		
	}
	public static void CreateStudent(Student student, Scanner s)
	{
		do
		{
			System.out.print("student name? : ");
			student.name = s.nextLine();
			if(student.name.equals(""))
			{
				System.out.println("name 값은 공백을 허용하지 않습니다.");
				continue;
			}
			try {
				System.out.print("student age? : ");
				student.age = Integer.parseInt(s.nextLine());
				if(student.age <= 0 )
				{
					System.out.println("학생이 0살 이하일 수 없습니다.");
					continue;
				}
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("잘못된 입력값입니다.");
				continue;
			}

			System.out.print("student number? : ");
			student.studentNumber = s.nextLine();
			if(student.studentNumber.equals(""))
			{
				System.out.println("student number 값은 공백을 허용하지 않습니다.");
				continue;
			}
			System.out.print("student major code? : ");
			student.majorCode = s.nextLine();
			if(student.majorCode.equals(""))
			{
				System.out.println("majorCode 값은 공백을 허용하지 않습니다.");
				continue;
			}
			student.regDate = new Date();
		}while(student.name.equals("") || 
			   student.age <= 0 ||
			   student.studentNumber.equals("") || 
			   student.majorCode.equals(""));
		//while 괄호 안의 순서를 바꿨을 때의 결과를 예측해보시오. 왜 이 순서대로 했는지 생각해보시오.
	}
	
	public static void CreateMajor(Major major, Scanner s)
	{
		do
		{
			System.out.print("major name ? : ");
			major.name = s.nextLine();
			if(major.name.equals(""))
			{
				System.out.println("name 값은 공백을 허용하지 않습니다.");
				continue;
			}
			System.out.print("major code? : ");
			major.code = s.nextLine();
			if(major.code.equals(""))
			{
				System.out.println("code 값은 공백을 허용하지 않습니다.");
				continue;
			}
			major.regDate = new Date();
		}while(major.name.equals("") || major.code.equals(""));
		//while 괄호 안의 순서를 바꿔서 실행해보시오.	(OR문의 논리적 특성)
	}

}
