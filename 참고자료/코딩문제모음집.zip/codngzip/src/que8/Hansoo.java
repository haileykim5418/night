package que8;

import java.io.*;
import java.util.Scanner;
public class Hansoo
{
	static boolean checkHansoo(int input)
{
		//숫자의 자리수 구하기
		int digit = String.valueOf(input).length();

		if(digit <= 2) 
		{
			return true;
		}
		else
		{
			int diff = 0;
			int previous = 0;
			for(int i = 0; i<digit-1; i++)
			{
				diff = Character.getNumericValue
						((String.valueOf(input).charAt(i)))
						- Character.getNumericValue
						((String.valueOf(input).charAt(i+1)));
//				diff = diff < 0 ? -1 * diff : diff;
				if(i==0)
				{
					previous = diff;
				}
				else
				{
					if(diff!=previous)
						return false;
					else
					{
						previous = diff;
					}
				}
			}

			if(diff!=previous)
				return false;
			else
				return true;
		}
		//그 숫자의 자리수만한 배열을 선언
		//인덱스로 이동하면서 인덱스간의 차이가 동일한지 볼 것
		//동일하면 true 아니면 false
	}
    public static void main(String[] args)
    {
        try {
			Scanner scan = new Scanner(System.in);
			int input = Integer.parseInt(scan.nextLine());
			int count = 0;
			for(int i = 1; i <=input; i++ )
			{
				if(checkHansoo(i))
					count++;
			}
			
			System.out.println(count);
		} catch (Exception e) {
			// TODO: handle exception
		}
    }
}