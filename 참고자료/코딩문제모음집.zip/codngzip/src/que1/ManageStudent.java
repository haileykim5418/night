package que1;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;


public class ManageStudent {

	public static void main(String[] args) {

		ArrayList<Student> students = new ArrayList<Student>();
		
		//문제1-2 변수 생성 및 3번 ArrayList에 저장
		Student student_ldj = new Student("이동준", 2009038033, "남");
		students.add(student_ldj);
		
		//아래 두 데이터들도 student_ljy, 
		//student_pjh 이런식으로 변수 생성 후 
		//add 해도 되지만 add 안에서 바로 new를 해도 된다.
		
		//단, student_ldj 변수 한개를 가지고 속성 바꿔서
		//다시 add하면 안 된다(참조변수의 특성, 얕은복사와 깊은 복사 개념!!!)
		students.add(new Student("이제영", 2007012034, "여"));
		students.add(new Student("박준현", 2002012034, "남"));

		for(int i = 0; i < students.size(); i++)
		{
			if(students.get(i).name.equals("이동준"))
			{
				students.get(i).setNumber(2019038033);
			}
		}

		for(int i = students.size()-1; i >= 0; i--)//역for문
		{
			if(students.get(i).name.equals("박준현"))
			{
				students.remove(i);
				break;
			}
			
		}
		for(int i = 0; i <2; i++)
		{
			Scanner scan = new Scanner(System.in);
			System.out.println("이름은?");
			String newStudentName = scan.nextLine();
			System.out.println("학번은?");
			int newStudentNumber = scan.nextInt(); //숫자\n
			scan.nextLine(); //\n을 흡수
			System.out.println("성별은?");
			String newStudentGender = scan.nextLine();
			students.add(new Student(newStudentName, newStudentNumber, newStudentGender));
			if(i == 1)
				scan.close();
		}
		
		for(Student item : students)
		{
			System.out.println(item);
		}

	}
	

}

