package que1;

//1번의 1번문제 - 클래스 작성
class Student {

	String name;
	int number;
	String gender;
	
	public Student(String n, int i, String g)
	{
		name = n;
		number = i;
		gender = g;		
	}
	
	public void setNumber(int n)
	{
		number = n;
	}
	
	public String toString()
	{
		return "이름 : " + name + " 번호 : " + number + " 성별: " + gender;
	}
}
