package Question11;

import java.util.ArrayList;
import java.util.Random;

public class randomNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Random random = new Random();
		ArrayList<Integer> arr = new ArrayList<Integer>();
		do
		{

			int computerInput = random.nextInt(10); //0~9반환함
			if(!arr.contains(computerInput))
			{
				arr.add(computerInput);
			}
		} while(arr.size()<4);
		
		for(int item : arr)
		{
			System.out.print(item + " ");
		}
		
	}

}
