package Question10;

import java.util.Random;
import java.util.Scanner;

public class scissorrockpaper {
	
	static final int SCISSORS = 0;
	static final int ROCK = 1;
	static final int PAPER = 2;
	
	public static void main(String[] args) {
		
		System.out.println("가위 바위 보(가위,바위,보만 입력할 것)");
		Scanner input = new Scanner(System.in);
		String myInput = input.nextLine();
		if(!myInput.equals("가위")&&!myInput.equals("바위")&&!myInput.equals("보"))
		{
			System.out.println("잘못된 입력입니다.");
			return; //프로그램을 종료시켜버림
		}
		
		Random random = new Random();
		int computerInput = random.nextInt(3); //0, 1, 2 반환함
		//여기서 0은 가위, 1은 바위, 2는 보로 약속한다.
		
		switch (myInput) {
		case "가위":
			switch (computerInput) {
			case SCISSORS:
				System.out.println("나 : 가위, 컴퓨터 : 가위, 무승부!!!");
				break;
			case ROCK:
				System.out.println("나 : 가위, 컴퓨터 : 바위, 패배!!!");
				break;
			case PAPER:
				System.out.println("나 : 가위, 컴퓨터 : 보, 승리!!!");
				break;
			}
			break;
		case "바위": 
			switch (computerInput) {
			case SCISSORS:
				System.out.println("나 : 바위, 컴퓨터 : 가위, 승리!!!");
				break;
			case ROCK:
				System.out.println("나 : 바위, 컴퓨터 : 바위, 무승부!!!");
				break;
			case PAPER:
				System.out.println("나 : 바위, 컴퓨터 : 보, 패배!!!");
				break;
			}
			break;
		case "보": 
			switch (computerInput) {
			case SCISSORS:
				System.out.println("나 : 보, 컴퓨터 : 가위, 패배!!!");
				break;
			case ROCK:
				System.out.println("나 : 보, 컴퓨터 : 바위, 승리!!!");
				break;
			case PAPER:
				System.out.println("나 : 보, 컴퓨터 : 보, 무승부!!!");
				break;
			}
			break;
		}
		
		
		
	}
}
