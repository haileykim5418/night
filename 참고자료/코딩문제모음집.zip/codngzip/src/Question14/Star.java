package Question14;

import java.util.Scanner;

public class Star {

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);
		int N = scan.nextInt();

		for(int i = 0; i<2*N; i++)
		{			
			int onOffSwitch = i;
			for(int j = 0; j < N; j++)
			{
				if(onOffSwitch%2 == 0)
				{
					System.out.print("*");
				}
				else
				{
					System.out.print(" ");
				}
				onOffSwitch++;
			}
			System.out.print("\n");
			
		}
		
    }

}
