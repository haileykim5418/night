package que7;

import java.io.*;

public class SelfNumber {

	public static void main(String[] args) {
		try {

			boolean[] check = new boolean[10001];
			for (int i = 1; i < check.length; i++) {
				int index = solution(i); // i 값이 셀프넘버가 있는 값인지 여부 판단
				if (index < 10001) // 10000미만이어야 함. 10001부터 하ㅡㄴ 이유는 1부터 써야해서(0은 안 쓰고)
				{
					check[index] = true;
				}
			}

			for (int i = 1; i < check.length; i++) {
				if (check[i] == false)
					System.out.print(String.valueOf(i) + "\n");
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

	}

	static int solution(int n) // 셀프 넘버 보유 여부 확인
	{
		int sum = n;
		while (true) {
			if (n == 0)
				break;
			sum += n % 10;// 1의자리 더해주기
			n = n / 10; // 한 자리씩 없애기
		}
		return sum;
	}
}
