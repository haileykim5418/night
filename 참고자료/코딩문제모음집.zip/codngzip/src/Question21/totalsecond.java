package Question21;

import java.util.Scanner;

public class totalsecond {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner s = new Scanner(System.in);
		//숫자를 입력받으면 그걸 시간과 분으로 바꿔주는 것!
		System.out.print("Input Total Second? ");
		int input = s.nextInt();
		int Minute;
		int Second;
		
		Minute = input / 60; //123/60 = 2.05 -> Hour 2가 들어감
		Second = input % 60; //123을 60으로 나눴을 때 나머지 3. 몫 2
		System.out.println(Minute+"min "+Second+"sec");
	}

}
