package que6;

import java.util.Scanner;

public class YearBirth {

	public static void main
	(String[] args) {
		// TODO Auto-generated method stub
		System.out.println
		("현재 몇 월 인가요(숫자만 입력하세요.)");
		
		Scanner scan = 
				new Scanner(System.in);
		
		int month = scan.nextInt();
		scan.close();
		
		//12, 1, 2 겨울
		//3, 4, 5 봄
		//6, 7, 8 여름
		//9, 10, 11 가을
		if(month==12 || (month < 3 && month > 0 ))
		{
			System.out.println
			("겨울");
		}
		else if(month >=3 && month<6)
		{
			System.out.println
			("봄");
		}
		else if(month >= 6 && month<9)
		{
			System.out.println
			("여름");
		}
		else if (month >= 9 && month < 12)
		{
			System.out.println
			("가을");
		}
		else
		{
			System.out.println
			("잘못된 값입니다.");
		}
		
		
	}

}
